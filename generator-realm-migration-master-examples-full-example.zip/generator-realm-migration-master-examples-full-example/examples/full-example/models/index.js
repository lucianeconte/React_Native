import { Dog } from './Dog';
export const Models = [Dog];