export default (oldRealm, newRealm) => {
    // TODO: Do something in here for the migration!
}