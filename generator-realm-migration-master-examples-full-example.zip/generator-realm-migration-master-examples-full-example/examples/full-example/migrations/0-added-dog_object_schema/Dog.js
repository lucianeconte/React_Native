export default { "name": "Dog", "properties": { "name": { "type": "string" } } }
;