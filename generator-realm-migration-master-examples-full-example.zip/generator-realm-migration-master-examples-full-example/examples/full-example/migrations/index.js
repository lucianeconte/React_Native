const migrations = [];

import migration0 from './0-added-dog_object_schema/';
migrations.push(migration0);


export default migrations;