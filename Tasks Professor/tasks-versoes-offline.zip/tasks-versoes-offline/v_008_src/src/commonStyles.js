export default {
    fontFamily: 'Lato',
    colors: {
        secondary: '#FFF',
        mainText: '#222',
    }
}