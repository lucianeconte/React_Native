import React, { Component } from 'react'
import { View, Text } from 'react-native'

export default class TaskList extends Component {
    render() {
        return (
            <View>
                <Text>TaskList</Text>
            </View>
        )
    }
}