export default {
    fontFamily: 'Lato',
    colors: {
        today: '#B13B44',
        secondary: '#FFF',
        mainText: '#222',
        subText: '#555',
    }
}