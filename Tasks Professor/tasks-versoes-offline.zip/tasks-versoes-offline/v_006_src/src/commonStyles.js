export default {
    fontFamily: 'Lato',
    colors: {
        secondary: '#FFF'
    }
}